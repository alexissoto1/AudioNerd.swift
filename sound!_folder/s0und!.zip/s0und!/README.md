# helloSine

## Summary

helloSine is a simple app that uses a UISlider object to control the frequency of an oscillator.

It provides three buttons – Play Sine, Play Square, and Stop, to perform these actions with a source .csd file.

## Topics Covered

- UISlider, UILabel.
- Constraints.
- The “chnget” opcode, the concept of named channels.
- The CsoundUI class, its basic methods and UI object wrappers, arguments to method calls.
- viewDidLoad(), basic iOS app structure.
- The sendScore method from CsoundObj.
- maxalloc in Csound.

## Assignment

Modify this project to add and/or change some functionality. The .csd file can also be substituted or modified. A good exercise is also to try to recreate this project from scratch – it is available as a reference, but re-implementing these behaviors can be helpful practice.

__Starter exercises to the reader:__

- Add another slider to control another parameter.
- Use another kind of UI object to control some parameter to be passed to Csound.
